from flask import Flask, render_template, request, jsonify

# Create Flask app
app = Flask(__name__)

# Updated chatbot answers
chat_data = {
    "hello": "Hi there! Welcome to ABC Health Center. How can I help you today?",
    "what time do you open": "We are open 24 hours. OPD services are available from 8 AM to 6 PM.",
    "is heart treatment available": "Yes, our hospital has a specialized cardiology unit for heart-related care.",
    "how do i schedule a visit": "You can schedule a visit by calling (987) 654-3210 or booking online.",
    "can you tell me about your doctors": "Sure! We have Dr. Ayesha (Heart), Dr. Imran (Brain), and Dr. Zainab (ENT).",
    "where are you based": "We are located at 456 Health Avenue, Lahore.",
    "how can i reach you": "Feel free to call us at (987) 654-3210 for any information."
}

# Home page route
@app.route("/")
def main_page():
    return render_template("index.html")

# Route to handle user messages
@app.route("/reply", methods=["POST"])
def reply_from_bot():
    message = request.form["msg"].lower()
    answer = chat_data.get(message, "I'm not sure I got that. Try asking something else.")
    return jsonify({"response": answer})

# Run the app
if __name__ == "__main__":
    app.run(debug=True)
